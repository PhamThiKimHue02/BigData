# Copyright (c) 2025 Robert Bosch GmbH
# SPDX-License-Identifier: AGPL-3.0

import os
import cv2
import json
import torch
import random
import logging
import argparse
import numpy as np
from PIL import Image
from skimage import measure
from tabulate import tabulate
import torch.nn.functional as F
import torchvision.transforms as transforms
from sklearn.metrics import auc, roc_auc_score, average_precision_score, f1_score, precision_recall_curve, pairwise
from sklearn.preprocessing import label_binarize

import open_clip
from few_shot import memory
from model import LinearLayer
from dataset import VisaDataset, MVTecDataset, MPDDDataset, VisaDatasetV2, MADDataset, RealIADDataset_v2
from prompts.prompt_ensemble_visa_19cls_single import encode_text_with_prompt_ensemble as encode_text_with_prompt_ensemble_visa
from prompts.prompt_ensemble_mvtec_20cls import encode_text_with_prompt_ensemble as encode_text_with_prompt_ensemble_mvtec
from prompts.new_prompt_ensemble_mpdd import encode_text_with_prompt_ensemble as encode_text_with_prompt_ensemble_mpdd
from prompts.prompt_ensemble_mad_real import encode_text_with_prompt_ensemble as encode_text_with_prompt_ensemble_mad_real
from prompts.prompt_ensemble_mad_sim import encode_text_with_prompt_ensemble as encode_text_with_prompt_ensemble_mad_sim
from prompts.prompt_ensemble_real_IAD import encode_text_with_prompt_ensemble as encode_text_with_prompt_ensemble_real_iad

product_type2defect_type_mvtec = {
    'bottle': ['good', 'broken', 'contamination'],
    'cable': ['good', 'bent', 'misplaced', 'combined', 'cut', 'missing', 'poke'],
    'capsule': ['good', 'crack', 'faulty imprint','poke', 'scratch', 'squeeze'],
    'carpet': ['good', 'color', 'cut', 'hole', 'contamination', 'thread'],
    'grid': ['good', 'bent', 'broken', 'glue', 'contamination', 'thread'],
    'hazelnut': ['good', 'crack', 'cut', 'hole', 'faulty imprint'],
    'leather': ['good', 'color', 'cut', 'misplaced', 'glue', 'poke'],
    'metal_nut': ['good', 'bent', 'color', 'misplaced', 'scratch'],
    'pill': ['good', 'color', 'combined', 'contamination', 'crack', 'faulty imprint', 'damaged', 'scratch'],
    'screw': ['good', 'fabric', 'scratch', 'thread'],
    'tile': ['good', 'crack', 'glue', 'damaged', 'liquid', 'rough'],
    'toothbrush': ['good', 'damaged'],
    'transistor': ['good', 'bent', 'cut', 'damaged', 'misplaced'],
    'wood': ['good', 'color', 'combined', 'hole', 'liquid', 'scratch'],
    'zipper': ['good', 'broken', 'combined', 'fabric', 'rough', 'misplaced', 'squeeze']
}


product_type2defect_type_visa = {
    'candle': ['normal', 'damage', 'weird wick', 'partical', 'melded', 'spot', 'extra', 'missing'],
    'capsules': ['normal', 'bubble'],
    'cashew': ['normal', 'scratch', 'breakage','burnt', 'stuck', 'hole', 'spot'],
    'chewinggum': ['normal', 'scratch', 'spot', 'missing'],
    'fryum': ['normal', 'scratch', 'breakage', 'burnt', 'stuck', 'spot'],
    'macaroni1': ['normal', 'scratch', 'crack', 'spot', 'chip'],
    'macaroni2': ['normal', 'scratch', 'breakage', 'crack', 'spot', 'chip'],
    'pcb1': ['normal', 'scratch', 'melt', 'bent', 'missing'],
    'pcb2': ['normal', 'scratch', 'melt', 'bent', 'missing'],
    'pcb3': ['normal', 'scratch', 'melt', 'bent', 'missing'],
    'pcb4': ['normal', 'scratch', 'damage', 'extra', 'burnt', 'missing', 'wrong place'],
    'pipe_fryum': ['normal', 'scratch', 'breakage', 'burnt', 'stuck', 'spot']
}


product_type2defect_type_mpdd = {
    'bracket_black': ['good', 'hole', 'scratch'],
    'bracket_brown': ['good', 'mismatch', 'bent'],
    'bracket_white': ['good', 'defective painting', 'scratch'],
    'connector': ['good', 'mismatch'],
    'metal_plate': ['good', 'rust', 'scratch'],
    'tubes': ['good', 'flattening']
}

product_type2defect_type_mad_real = {
    'Bear': ['good', 'Stains'],
    'Bird': ['good', 'Missing'],
    'Elephant': ['good', 'Missing'],
    'Parrot': ['good', 'Missing'],
    'Pig': ['good', 'Missing'],
    'Puppy': ['good', 'Stains'],
    'Scorpion': ['good', 'Missing'],
    'Turtle': ['good', 'Stains'],
    'Unicorn': ['good', 'Missing'],
    'Whale': ['good', 'Stains']
}

product_type2defect_type_mad_sim = {
    'Gorilla': ['good', 'Stains', 'Burrs', 'Missing'],
    'Unicorn': ['good', 'Stains', 'Burrs', 'Missing'],
    'Mallard': ['good', 'Stains', 'Burrs', 'Missing'],
    'Turtle': ['good', 'Stains', 'Burrs', 'Missing'],
    'Whale': ['good', 'Stains', 'Burrs', 'Missing'],
    'Bird': ['good', 'Stains', 'Burrs', 'Missing'],
    'Owl': ['good', 'Stains', 'Burrs', 'Missing'],
    'Sabertooth': ['good', 'Stains', 'Burrs', 'Missing'],
    'Swan': ['good', 'Stains', 'Burrs', 'Missing'],
    'Sheep': ['good', 'Stains', 'Burrs', 'Missing'],
    'Pig': ['good', 'Stains', 'Burrs', 'Missing'],
    'Zalika': ['good', 'Stains', 'Burrs', 'Missing'],
    'Pheonix': ['good', 'Stains', 'Burrs', 'Missing'],
    'Elephant': ['good', 'Stains', 'Burrs', 'Missing'],
    'Parrot': ['good', 'Stains', 'Burrs', 'Missing'],
    'Cat': ['good', 'Stains', 'Burrs', 'Missing'],
    'Scorpion': ['good', 'Stains', 'Burrs', 'Missing'],
    'Obesobeso': ['good', 'Stains', 'Burrs', 'Missing'],
    'Bear': ['good', 'Stains', 'Burrs', 'Missing'],
    'Puppy': ['good', 'Stains', 'Burrs', 'Missing'],
}
product_type2defect_type_real_iad = {
    'switch': ['good', 'missing', 'contamination', 'scratch'], 
    'eraser': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'woodstick': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'zipper': ['good', 'contamination', 'deformation', 'missing', 'damage'], 
    'fire_hood': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'pcb': ['good', 'contamination', 'scratch', 'missing', 'foreign'], 
    'toothbrush': ['good', 'abrasion', 'contamination', 'missing'], 
    'plastic_nut': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'wooden_beads': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'transistor1': ['good', 'missing', 'contamination', 'deformation'], 
    'bottle_cap': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'u_block': ['good', 'abrasion', 'contamination', 'scratch', 'missing'], 
    'sim_card_set': ['good', 'abrasion', 'contamination', 'scratch'], 
    'end_cap': ['good', 'contamination', 'scratch', 'missing', 'damage'], 
    'usb': ['good', 'contamination', 'deformation', 'scratch', 'missing'], 
    'regulator': ['good', 'missing', 'scratch'], 
    'plastic_plug': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'audiojack': ['good', 'contamination', 'deformation', 'scratch', 'missing'], 
    'mint': ['good', 'missing', 'contamination', 'foreign'], 
    'toy_brick': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'toy': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'rolled_strip_base': ['good', 'pit', 'missing', 'contamination'], 
    'terminalblock': ['good', 'pit', 'missing', 'contamination', ], 
    'mounts': ['good', 'missing', 'contamination', 'pit'], 
    'button_battery': ['good', 'abrasion', 'contamination', 'scratch', 'pit'], 
    'porcelain_doll': ['good', 'abrasion', 'contamination', 'scratch'], 
    'phone_battery': ['good', 'contamination', 'scratch', 'damage', 'pit'], 
    'usb_adaptor': ['good', 'abrasion', 'contamination', 'scratch', 'pit'], 
    'vcpill': ['good', 'contamination', 'scratch', 'missing', 'pit'], 
    'tape': ['good', 'missing', 'contamination', 'damage']
}

import re
from tqdm import tqdm

import pdb


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def normalize(pred, max_value=None, min_value=None):
    if max_value is None or min_value is None:
        return (pred - pred.min()) / (pred.max() - pred.min())
    else:
        return (pred - min_value) / (max_value - min_value)


def apply_ad_scoremap(image, scoremap, alpha=0.5):
    np_image = np.asarray(image, dtype=float)
    scoremap = (scoremap * 255).astype(np.uint8)
    scoremap = cv2.applyColorMap(scoremap, cv2.COLORMAP_JET)
    scoremap = cv2.cvtColor(scoremap, cv2.COLOR_BGR2RGB)
    return (alpha * np_image + (1 - alpha) * scoremap).astype(np.uint8)


def cal_pro_score(masks, amaps, max_step=200, expect_fpr=0.3):
    # ref: https://github.com/gudovskiy/cflow-ad/blob/master/train.py
    binary_amaps = np.zeros_like(amaps, dtype=bool)
    min_th, max_th = amaps.min(), amaps.max()
    delta = (max_th - min_th) / max_step
    pros, fprs, ths = [], [], []
    for th in np.arange(min_th, max_th, delta):
        binary_amaps[amaps <= th], binary_amaps[amaps > th] = 0, 1
        pro = []
        for binary_amap, mask in zip(binary_amaps, masks):
            for region in measure.regionprops(measure.label(mask)):
                tp_pixels = binary_amap[region.coords[:, 0], region.coords[:, 1]].sum()
                pro.append(tp_pixels / region.area)
        inverse_masks = 1 - masks
        fp_pixels = np.logical_and(inverse_masks, binary_amaps).sum()
        fpr = fp_pixels / inverse_masks.sum()
        pros.append(np.array(pro).mean())
        fprs.append(fpr)
        ths.append(th)
    pros, fprs, ths = np.array(pros), np.array(fprs), np.array(ths)
    idxes = fprs < expect_fpr
    fprs = fprs[idxes]
    fprs = (fprs - fprs.min()) / (fprs.max() - fprs.min())
    pro_auc = auc(fprs, pros[idxes])
    return pro_auc


def test(args):
    img_size = args.image_size
    features_list = args.features_list
    few_shot_features = args.few_shot_features
    dataset_dir = args.data_path
    save_path = args.save_path
    dataset_name = args.dataset
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    txt_path = os.path.join(save_path, 'log.txt')



    # clip
    model, _, preprocess = open_clip.create_model_and_transforms(args.model, img_size, pretrained=args.pretrained)
    model.to(device)
    tokenizer = open_clip.get_tokenizer(args.model)

    # logger
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    root_logger.setLevel(logging.WARNING)
    logger = logging.getLogger('test')
    formatter = logging.Formatter('%(asctime)s.%(msecs)03d - %(levelname)s: %(message)s',
                                  datefmt='%y-%m-%d %H:%M:%S')
    logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler(txt_path, mode='a')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # record parameters
    for arg in vars(args):
        if args.mode == 'zero_shot' and (arg == 'k_shot' or arg == 'few_shot_features'):
            continue
        logger.info(f'{arg}: {getattr(args, arg)}')

    # seg
    with open(args.config_path, 'r') as f:
        model_configs = json.load(f)
    linearlayer = LinearLayer(model_configs['vision_cfg']['width'], model_configs['embed_dim'],
                              len(features_list), args.model).to(device)
    checkpoint = torch.load(args.checkpoint_path)
    linearlayer.load_state_dict(checkpoint["trainable_linearlayer"])

    # dataset
    transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.CenterCrop(img_size),
            transforms.ToTensor()
        ])
    # datasets
    if args.dataset == 'mvtec':
        test_data = MVTecDataset(root=dataset_dir, transform=preprocess, target_transform=transform, aug_rate=-1, mode='test')
        gt_defect = {"good":0, "bent":1, "bent_lead":1, "bent_wire":1, "broken":2, "broken_large":2, "broken_small":2, "broken_teeth":2, "color":3, "combined":4, "contamination":5, "metal_contamination":5, "crack":6, "cut":7, "cut_inner_insulation":7, "cut_lead":7, "cut_outer_insulation":7, "fabric":8, "manipulated_front":8, "fabric_border":8, "fabric_interior":8, "faulty_imprint":9, "print":9, "glue":10, "glue_strip":10, "hole":11, "missing":12, "missing_wire":12, "missing_cable":12, "poke":13, "poke_insulation":13, "rough":14, "scratch":15, "scratch_head":15, "scratch_neck":15, "squeeze":16, "squeezed_teeth":16, "thread":17, "thread_side":17, "thread_top":17, "liquid":18, "oil":18, "misplaced":19, "cable_swap":19, "flip":19, "fold":19, "split_teeth":19, "damaged_case":20, "defective":20, "gray_stroke":20, "pill_type":20}  
        defects = ['good', 'bent', 'broken', 'color', 'combined', 'contamination', 'crack', 'cut', 'fabric', 'faulty imprint', 'glue', 'hole', 'missing', 'poke', 'rough', 'scratch', 'squeeze', 'thread', 'liquid', 'misplaced', 'damaged']
        p_cls2d_cls = product_type2defect_type_mvtec
        
    elif args.dataset == 'visa':
        test_data = VisaDatasetV2(root=dataset_dir, transform=preprocess, target_transform=transform)
        gt_defect = {'normal': 0, 'damage': 1, 'scratch':2, 'breakage': 3, 'burnt': 4, 'weird wick': 5, 'stuck': 6, 'crack': 7, 'wrong place': 8, 'partical': 9, 'bubble': 10, 'melded': 11, 'hole': 12, 'melt': 13, 'bent':14, 'spot': 15, 'extra': 16, 'chip': 17, 'missing': 18}
        defects = ['normal', 'damage', 'scratch', 'breakage', 'burnt', 'weird wick', 'stuck', 'crack', 'wrong place', 'partical', 'bubble', 'melded', 'hole', 'melt', 'bent', 'spot', 'extra', 'chip', 'missing']
        p_cls2d_cls = product_type2defect_type_visa
    elif args.dataset == 'mpdd':
        test_data = MPDDDataset(root=dataset_dir, transform=preprocess, target_transform=transform, aug_rate=-1, mode='test')
        gt_defect =  {"good":0, 'hole':1, 'scratches':2, 'bend_and_parts_mismatch':3, 'parts_mismatch':4, 'defective_painting':5, 'major_rust':6, 'total_rust':6, 'flattening':7}
        defects = ['good', 'hole', 'scratch', 'bent', 'mismatch', 'defective painting', 'rust', 'flattening']
        p_cls2d_cls = product_type2defect_type_mpdd
    elif args.dataset == 'mad_sim':
        test_data = MADDataset(root=dataset_dir, transform=preprocess, target_transform=transform, mode='test')
        gt_defect =  {"good":0, 'Stains':1, 'Missing':2, 'Burrs':3}
        defects = ['good', 'Stains', 'Missing', 'Burrs']
        p_cls2d_cls = product_type2defect_type_mad_sim
    elif args.dataset == 'mad_real':
        test_data = MADDataset(root=dataset_dir, transform=preprocess, target_transform=transform, mode='test')
        gt_defect =  {"good":0, 'Stains':1, 'Missing':2}
        defects = ['good', 'Stains', 'Missing']
        p_cls2d_cls = product_type2defect_type_mad_real

    elif args.dataset == 'real_iad':
        test_data = RealIADDataset_v2(root=dataset_dir, transform=preprocess, aug_rate=-1, target_transform=transform, mode='test')
        gt_defect =  {"good":0, 'pit':1, 'deformation':2, 'abrasion':3, 'scratch':4, 'damage':5, 'missing':6, 'foreign':7, 'contamination':8}
        defects = ['good', 'pit', 'deformation', 'abrasion', 'scratch', 'damage', 'missing', 'foreign', 'contamination']
        p_cls2d_cls = product_type2defect_type_real_iad
    test_dataloader = torch.utils.data.DataLoader(test_data, batch_size=1, shuffle=False)
    obj_list = test_data.get_cls_names()



    # text prompt
    with torch.cuda.amp.autocast(), torch.no_grad():
        if args.dataset == 'mvtec':
            text_prompts = encode_text_with_prompt_ensemble_mvtec(model, obj_list, tokenizer, device)
        elif args.dataset == 'visa':
            text_prompts = encode_text_with_prompt_ensemble_visa(model, obj_list, tokenizer, device)
        elif args.dataset == 'mpdd':
            text_prompts = encode_text_with_prompt_ensemble_mpdd(model, obj_list, tokenizer, device)
        elif args.dataset == 'mad_sim':
            text_prompts = encode_text_with_prompt_ensemble_mad_sim(model, obj_list, tokenizer, device)
        elif args.dataset == 'mad_real':
            text_prompts = encode_text_with_prompt_ensemble_mad_real(model, obj_list, tokenizer, device)
        elif args.dataset == 'real_iad':
            text_prompts = encode_text_with_prompt_ensemble_real_iad(model, obj_list, tokenizer, device)
    results = {}
    results['cls_names'] = []
    results['imgs_masks'] = []
    results['anomaly_maps'] = []
    results['gt_sp'] = []
    results['pr_sp'] = []
    class_ids = []
    for items in test_dataloader:
        image = items['img'].to(device)
        cls_name = items['cls_name']
        paths = items['img_path']
        results['cls_names'].append(cls_name[0])

        img_masks = items['img_mask']
        if args.dataset == 'mvtec' or args.dataset == 'mpdd' :
            defect_cls_id = []               
            for i in paths:
                match = re.search(r'\/([^\/]+)\/[^\/]*$', i) # './data/mvtec/transistor/test/good/004.png', './data/mvtec/carpet/test/hole/002.png', './data/mvtec/metal_nut/test/scratch/004.png',
                defect_cls_id.append(int(gt_defect[str(match.group(1))]))
        elif args.dataset == 'visa' or args.dataset == 'mad_sim' or args.dataset == 'mad_real' or args.dataset =='real_iad':
            defect_cls = items['defect_cls']
            defect_cls_id = [gt_defect[name] for name in defect_cls]

        gt_mask = items['img_mask']
        
        for i in range(gt_mask.size(0)):
            gt_mask[i][gt_mask[i] > 0.5], gt_mask[i][gt_mask[i] <= 0.5] = p_cls2d_cls[cls_name[i]].index(defects[defect_cls_id[i]]), 0 
        

        results['imgs_masks'].append(gt_mask)  # px
        results['gt_sp'].append(items['anomaly'].item())

        with torch.no_grad(), torch.cuda.amp.autocast():
            image_features, patch_tokens = model.encode_image(image, features_list)
            image_features /= image_features.norm(dim=-1, keepdim=True)
            text_features = []
            for cls in cls_name:
                defects_indices = [defects.index(d) for d in p_cls2d_cls[cls]]
                text_features.append(text_prompts[cls][:,defects_indices])

            
            text_features = torch.stack(text_features, dim=0)

            # sample
            text_probs = ((image_features @ text_features[0]) * 100.).softmax(dim=-1) # B, H, W
            # pdb.set_trace()
            results['pr_sp'].append(sum(text_probs[0][1:]).cpu().item())

            # pixel
            patch_tokens = linearlayer(patch_tokens)
            anomaly_maps = []
            for layer in range(len(patch_tokens)):
                patch_tokens[layer] /= patch_tokens[layer].norm(dim=-1, keepdim=True)
                anomaly_map = ((patch_tokens[layer] @ text_features) * 100.)
                B, L, C = anomaly_map.shape
                H = int(np.sqrt(L))
                anomaly_map = F.interpolate(anomaly_map.permute(0, 2, 1).view(B, C, H, H),
                                            size=img_size, mode='bilinear', align_corners=True)
                anomaly_map = torch.softmax(anomaly_map, dim=1)
                # anomaly_map = torch.stack((anomaly_map[:,0], torch.amax(anomaly_map[:,1:], dim=1)), dim=1) # to binary anormaly map 
                # anomaly_map = torch.softmax(anomaly_map, dim=1)[:, 1]
                # anomaly_map = torch.softmax(anomaly_map, dim=1)[:, :, :, :]

                anomaly_maps.append(anomaly_map.cpu().numpy())
            anomaly_map = np.sum(anomaly_maps, axis=0)

            # few shot
            # if args.mode == 'few_shot':
            #     image_features, patch_tokens = model.encode_image(image, few_shot_features)
            #     anomaly_maps_few_shot = []
            #     for idx, p in enumerate(patch_tokens):
            #         if 'ViT' in args.model:
            #             p = p[0, 1:, :]
            #         else:
            #             p = p[0].view(p.shape[1], -1).permute(1, 0).contiguous()
            #         cos = pairwise.cosine_similarity(mem_features[cls_name[0]][idx].cpu(), p.cpu())
            #         height = int(np.sqrt(cos.shape[1]))
            #         anomaly_map_few_shot = np.min((1 - cos), 0).reshape(1, 1, height, height)
            #         anomaly_map_few_shot = F.interpolate(torch.tensor(anomaly_map_few_shot),
            #                                              size=img_size, mode='bilinear', align_corners=True)
            #         anomaly_maps_few_shot.append(anomaly_map_few_shot[0].cpu().numpy())
            #     anomaly_map_few_shot = np.sum(anomaly_maps_few_shot, axis=0)
            #     anomaly_map = anomaly_map + anomaly_map_few_shot
            
            results['anomaly_maps'].append(anomaly_map)

            # visualization
            # path = items['img_path']
            # cls = path[0].split('/')[-2]
            # filename = path[0].split('/')[-1]
            # vis = cv2.cvtColor(cv2.resize(cv2.imread(path[0]), (img_size, img_size)), cv2.COLOR_BGR2RGB)  # RGB
            # mask = normalize(anomaly_map[0])
            # vis = apply_ad_scoremap(vis, mask)
            # vis = cv2.cvtColor(vis, cv2.COLOR_RGB2BGR)  # BGR
            # save_vis = os.path.join(save_path, 'imgs', cls_name[0], cls)
            # if not os.path.exists(save_vis):
            #     os.makedirs(save_vis)
            # cv2.imwrite(os.path.join(save_vis, filename), vis)

    # metrics
    table_ls = []
    auroc_px_ls = []
    f1_px_ls = []
    aupro_ls = []
    ap_px_ls = []
    auroc_px_per_defect_cls_all = {}
    ap_px_per_defect_cls_all = {}
    f1_px_per_defect_cls_all = {}

    for obj in obj_list:
        table = []
        gt_px = []
        pr_px = []
        table.append(obj)
        for idxes in range(len(results['cls_names'])):
            if results['cls_names'][idxes] == obj:
                gt_px.append(results['imgs_masks'][idxes].squeeze(1).numpy())
                pr_px.append(results['anomaly_maps'][idxes])

        gt_px = np.array(gt_px) # (N_p, B, H, W)
        pr_px = np.array(pr_px) # (N_p, B, C, H, W)
        C = pr_px.shape[2]
        gt_px = gt_px.ravel()  # (N,)
        gt_px_b = label_binarize(gt_px, classes=range(C)) # (N, C)
        if C == 2:
            gt_px_b = np.hstack((1-gt_px_b, gt_px_b))
        pr_px = np.transpose(pr_px, (0,1,3,4,2)).reshape(-1, C) # (N, C)
        
        try:
            auroc_px = roc_auc_score(gt_px_b, pr_px, multi_class='ovr') #, multi_class='ovo', labels = class_ids)
            roc_auc_per_class = roc_auc_score(gt_px_b, pr_px, multi_class='ovr', average=None)
            for i, auc in enumerate(roc_auc_per_class):
                if p_cls2d_cls[obj][i] in auroc_px_per_defect_cls_all:
                    auroc_px_per_defect_cls_all[p_cls2d_cls[obj][i]].append(auc)
                else:
                    auroc_px_per_defect_cls_all[p_cls2d_cls[obj][i]] = [auc]
        except:
            print(obj)
            pdb.set_trace()
            exit()
        ap_px = average_precision_score(gt_px_b, pr_px, average='macro')
        ap_px_per_class = average_precision_score(gt_px_b, pr_px, average=None)
        for i, ap in enumerate(ap_px_per_class):
            if p_cls2d_cls[obj][i] in ap_px_per_defect_cls_all:
                ap_px_per_defect_cls_all[p_cls2d_cls[obj][i]].append(ap)
            else:
                ap_px_per_defect_cls_all[p_cls2d_cls[obj][i]] = [ap]

        # f1_px
        f1_px = f1_score(gt_px, np.argmax(pr_px, axis=-1), average='macro')
        f1_px_per_class = f1_score(gt_px, np.argmax(pr_px, axis=-1), average=None)
        for i, f1 in enumerate(f1_px_per_class):
            if p_cls2d_cls[obj][i] in f1_px_per_defect_cls_all:
                f1_px_per_defect_cls_all[p_cls2d_cls[obj][i]].append(f1)
            else:
                f1_px_per_defect_cls_all[p_cls2d_cls[obj][i]] = [f1]

        table.append(str(np.round(auroc_px * 100, decimals=1)))
        table.append(str(np.round(f1_px * 100, decimals=1)))
        table.append(str(np.round(ap_px * 100, decimals=1)))

        table_ls.append(table)
        auroc_px_ls.append(auroc_px)
        f1_px_ls.append(f1_px)
        ap_px_ls.append(ap_px)
    # logger
    per_defect_cls_table = []
    for defect in auroc_px_per_defect_cls_all:
        auroc = np.round(np.mean(auroc_px_per_defect_cls_all[defect]) * 100, decimals=6)
        ap = np.round(np.mean(ap_px_per_defect_cls_all[defect]) * 100, decimals=6)
        f1 = np.round(np.mean(f1_px_per_defect_cls_all[defect]) * 100, decimals=6)
        per_defect_cls_table.append([defect, auroc, ap, f1])
    results = tabulate(per_defect_cls_table, headers=['defects', 'auroc_px', 'f1_px', 'ap_px'], tablefmt="pipe")
    logger.info("\n%s", results)
    
    table_ls.append(['mean', str(np.round(np.mean(auroc_px_ls) * 100, decimals=1)),
                     str(np.round(np.mean(f1_px_ls) * 100, decimals=1)), str(np.round(np.mean(ap_px_ls) * 100, decimals=1)),
                     str(np.round(np.mean(aupro_ls) * 100, decimals=1))])
    results = tabulate(table_ls, headers=['objects', 'auroc_px', 'f1_px', 'ap_px'], tablefmt="pipe")
    logger.info("\n%s", results)


if __name__ == '__main__':
    parser = argparse.ArgumentParser("MultiADS", add_help=True)
    # paths
    parser.add_argument("--data_path", type=str, default="./data/visa", help="path to test dataset")
    parser.add_argument("--save_path", type=str, default='./results/mvtec_visa_multi_seg/zero_shot/', help='path to save results')
    parser.add_argument("--checkpoint_path", type=str, default='./exps/mvtec/epoch_2.pth ', help='path to save results')
    parser.add_argument("--config_path", type=str, default='./open_clip/model_configs/ViT-L-14-336.json ', help="model configs")
    # model
    parser.add_argument("--dataset", type=str, default='visa', help="test dataset")
    parser.add_argument("--model", type=str, default="ViT-L-14-336", help="model used")
    parser.add_argument("--pretrained", type=str, default="laion400m_e32", help="pretrained weight used")
    parser.add_argument("--features_list", type=int, nargs="+", default=[6, 12, 18, 24], help="features used")
    parser.add_argument("--few_shot_features", type=int, nargs="+", default=[6, 12, 18, 24], help="features used for few shot")
    parser.add_argument("--image_size", type=int, default=518, help="image size")
    parser.add_argument("--mode", type=str, default="zero_shot", help="zero shot or few shot")
    # few shot
    parser.add_argument("--k_shot", type=int, default=4, help="e.g., 10-shot, 5-shot, 1-shot")
    parser.add_argument("--seed", type=int, default=42, help="random seed")
    args = parser.parse_args()

    setup_seed(args.seed)
    test(args)
